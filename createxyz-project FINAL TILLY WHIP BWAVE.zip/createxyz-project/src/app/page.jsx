"use client";
import React from "react";

function MainComponent() {
  const [showPopup, setShowPopup] = React.useState(false);

  const connectWallet = async () => {
    await window.Moralis.enableWeb3();
    console.log("Wallet connected");
  };

  const purchaseNFT = async () => {
    const options = {
      type: "native",
      amount: window.Moralis.Units.ETH("0.03"),
      receiver: "0xYourWalletAddress",
    };
    let result = await window.Moralis.transfer(options);
    console.log("NFT purchased", result);
    setShowPopup(false);
  };

  React.useEffect(() => {
    const audio = document.getElementById("tilly-whip-preview");
    if (audio) {
      audio.play();
    }
  }, []);

  return (
    <div className="font-sans bg-gray-100">
      <header className="bg-gradient-to-r from-purple-500 to-blue-500 text-white py-4 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-3xl font-bold">B-Wave</h1>
          <nav>
            <ul className="flex space-x-4">
              <li>
                <a
                  href="#nft"
                  className="hover:text-yellow-300 transition-colors duration-300"
                >
                  NFT
                </a>
              </li>
              <li>
                <a
                  href="#music"
                  className="hover:text-yellow-300 transition-colors duration-300"
                >
                  Music
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="hover:text-yellow-300 transition-colors duration-300"
                >
                  Contact
                </a>
              </li>
            </ul>
          </nav>
          <button
            onClick={connectWallet}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors duration-300"
          >
            Connect Wallet
          </button>
        </div>
      </header>
      <main className="container mx-auto py-12">
        <section id="nft" className="mb-16">
          <h2 className="text-4xl font-bold text-center mb-8">
            B-WAVE'S LIMITED EDITION 'TILLY WHIP' NFT
          </h2>
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <img
                src="https://ucarecdn.com/c2d7b80f-7c39-4a93-987c-cb7f0755fb7d/"
                alt="Retro-style illustration of a woman in a space helmet with a cupcake and space shuttle"
                className="w-full rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
              />
            </div>
            <div className="md:w-1/2 md:pl-8">
              <h3 className="text-2xl font-bold mb-4">JULY 27, 2024</h3>
              <h4 className="text-xl font-semibold mb-4">
                TILLY WHIP (LIMITED EDITION SINGLE) PRE-RELEASE NFT
              </h4>
              <p className="mb-4 italic">
                WRITTEN AND PERFORMED BY B-WAVE
                <br />
                BEAT AND MIX BY SUNNYSONGBIRD
                <br />
                <br />A SURF LLC MUSIC PRODUCTION
              </p>
              <p className="mb-4">
                <strong>
                  We are giving away 10 limited edition NFT pre-release versions
                  of this song for free. Additionally, 1,101 of the same
                  'limited edition' NFTs will be available for purchase at $8.69
                  each. As a bonus, all 1,111 'Tilly Whip (Limited Edition
                  Single) Pre-Release' NFT holders will receive a free full
                  album download of the upcoming Delray Dude album by B-Wave and
                  SunnySongBird. To enter the giveaway, you can either purchase
                  one of the limited edition NFTs or enter for free by sending
                  an email with the subject "Tilly Whip" to bwave.nft@gmail.com.
                </strong>
              </p>
              <button
                onClick={() => setShowPopup(true)}
                className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition-colors duration-300"
              >
                Buy Tilly Whip NFT
              </button>
            </div>
          </div>
        </section>
        <section id="music" className="mb-16">
          <h2 className="text-4xl font-bold text-center mb-8">Music</h2>
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <h3 className="text-2xl font-bold mb-4">TILLY WHIP</h3>
            <p className="mb-4">LIMITED EDITION SINGLE NFT</p>
            <audio controls id="tilly-whip-preview" className="w-full" autoPlay>
              <source src="/tilly-whip-preview.mp3" type="audio/mpeg" />
              Your browser does not support the audio element.
            </audio>
            <p className="mt-4 text-xl font-bold">Price: $4.99</p>
          </div>
        </section>
        <section id="contact" className="mb-16">
          <h2 className="text-4xl font-bold text-center mb-8">Contact</h2>
          <form className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="mb-4">
              <label htmlFor="name" className="block mb-2 font-bold">
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block mb-2 font-bold">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="message" className="block mb-2 font-bold">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                required
                className="w-full px-3 py-2 border rounded h-32 focus:outline-none focus:ring-2 focus:ring-blue-500"
              ></textarea>
            </div>
            <button
              type="submit"
              className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-2 rounded hover:from-purple-500 hover:to-blue-500 transition-colors duration-300"
            >
              Submit
            </button>
          </form>
        </section>
      </main>
      <footer className="bg-gradient-to-r from-purple-500 to-blue-500 text-white py-8">
        <div className="container mx-auto text-center">
          <p>Official Release Date: July 27, 2024</p>
          <p>&copy; 2024 B-Wave. All rights reserved.</p>
        </div>
      </footer>
      {showPopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold mb-4">Purchase Tilly Whip NFT</h3>
            <p className="mb-4">Price: $8.69</p>
            <button
              onClick={purchaseNFT}
              className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition-colors duration-300"
            >
              Confirm Purchase
            </button>
            <button
              onClick={() => setShowPopup(false)}
              className="bg-gray-300 text-black px-6 py-2 rounded hover:bg-gray-400 transition-colors duration-300 mt-4"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;